
var prodb = [{
		id : "doll1",
		pname: "Plashy toy",
		price: 19.99,
		image:"./img/toy1.jpg",
		rating: 4.5
	},
	{
		id : "doll2",
		pname: "Teddy Bear",
		price: 9.99,
		image:"./img/toy2.jpg",
		rating: 3.5
	},
	{
		id : "gun1",
		pname: "Toy Gun",
		price: 12.08,
		image: "./img/gun1.jpg",
		rating: 4
	},
	{
		id : "other",
		pname: "Circles",
		price: 20.19,
		image: "./img/toy3.jpg",
		rating: 2
	}
]
